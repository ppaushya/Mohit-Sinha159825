package Practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.Spliterator;
import java.util.Vector;

public class ListMethodDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

List<String> lst=new ArrayList<>();
		
		lst.add("tom");
		lst.add("jack");
		lst.add("jerry");
		lst.add("tom");
		lst.add("null");
		
		List<String> lst1=new ArrayList<>();
		
		lst1.addAll(lst);
		for(String str:lst1)
			System.out.print(str+" ");
		System.out.println();
		System.out.println(lst1.addAll(lst));
		
		System.out.println(lst.size());
		
		System.out.println(lst.contains("jack"));
		
		lst1.clear();
		System.out.println(lst1.size());
		
		System.out.println(lst1.isEmpty());
		
		System.out.println(lst.get(3));
		
		 Object[] ob = lst.toArray();

	      System.out.println("Printing elements from first to last:"); 
	      for (Object value : ob) 
	         System.out.println("Element = " + value);
	      
	      lst.add(3, "Sam");
	      for(String str:lst)
				System.out.print(str+" ");
			System.out.println();
			
			lst1.addAll(lst);
			for(String str:lst1)
				System.out.print(str+" ");
			System.out.println();
			
//			ArrayList<String> listCopy=(ArrayList<String>) lst.clone();
			
			System.out.println(lst.containsAll(lst1));
			
			 ArrayList<Integer> arrlist = new ArrayList<Integer>(5);
		      arrlist.add(10);
		      arrlist.add(50);
		      arrlist.add(30);
		      arrlist.ensureCapacity(15);
		      for (Integer number : arrlist) 
		          System.out.println("Number = " + number);
			
		      System.out.println(lst.equals(lst1));
		      
		      System.out.println(lst.indexOf("jerry"));
			
		      System.out.println(lst.lastIndexOf("tom"));
			
		      ListIterator lstIterator = lst.listIterator(2);
		      
		        System.out.println("Iterating in forward direction from 2nd position");
		        while(lstIterator.hasNext())
		         System.out.print(lstIterator.next()+" ");
		        System.out.println();
		        
		        System.out.println(lst1.removeAll(lst));
		        
//		        Vector<String> vector = new Vector<String>();
//		        vector.add("R");
//		        vector.add("B");
//		        vector.add("R");
//		        System.out.println("Initial values are :"+vector);
//		        Collections.replaceAll(vector, "R", "Replace All");
//		        System.out.println("Value after replace :"+ vector);
		        
		        lst1.retainAll(lst);
		        for(String str:lst1)
					System.out.print(str+" ");
		        System.out.println();
		        
		        Spliterator<String> spliterator=lst.spliterator();
		        System.out.println(spliterator.SIZED);
		        
	}

}
