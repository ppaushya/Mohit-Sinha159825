package practice;

import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapDemo {

	public static void main(String[] args) {
			Map<Integer,String> map=new LinkedHashMap<>();
		map.put(1, "one");
		map.put(4,"two");
		map.put(3,"three");
		map.put(1,"four");//will override value of key=1
		map.put(2,"one");//value can be duplicate
		//map.put(null,"five");//null not allowed
//		map.put(null,"seven");
		map.put(111,"rdxg");
		map.put(65786,"hjgh");
		map.put(76,"nbvng");
		
		System.out.println(map);
		

	}

}
