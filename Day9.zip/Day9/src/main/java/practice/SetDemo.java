package practice;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeSet<Integer> set=new TreeSet<>();
		set.add(1);
		set.add(2455);
		set.add(3333);
		set.add(4);
		set.add(4);
		set.add(5);
		//set.add(null);//bcoz its hashset
		set.add(6);
		
		
			System.out.print(set+" ");
		System.out.println();
	}

}
