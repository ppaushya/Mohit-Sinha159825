package org.cap.demo;

public class SimpleInterest {
	double principle;
	float years;
	float rateofinterest;
	
public void getdata() {
	principle=4000;
	years=3.3f;
	rateofinterest=0.0065f;
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
