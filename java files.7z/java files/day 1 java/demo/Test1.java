package org.cap.demo;

public class Test1 {
	
	//instance variables
	int count;
	char ch;
	boolean flag;
	byte num;
	float pi;
	
	public static void main(String[] args) {
		int mynum=800;
		
		
		Test1 obj=new Test1();
		System.out.println(obj.ch);
		System.out.println(obj.flag);
		System.out.println(obj.count);
		System.out.println(obj.num);
		System.out.println(obj.pi);
		
		System.out.println("mynum="+mynum);
	}

}