package org.cap.demo;

public class testStatic {
	String name;
	static int count;
	final float pi=3.14f;
	
	public static void show()
	{
		System.out.println("count:" +count);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testStatic obj=new testStatic();
		obj.name="Tom";
		//TestStatic.count=10;
		obj.count=10;
		
		System.out.println("name:" +obj.name);
		System.out.println("count:"+obj.count);
		System.out.println("pi:"+obj.pi);
		
		testStatic obj1=new testStatic();
		obj1.name="Tommy";
		obj.count=100;
		
		System.out.println("Name:"+obj1.name);
		

	}

}
