package org.cap.loop.demo;

public class Testfor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=0;i<10;i++)
		{
			System.out.print(i);
		}

	}

}
