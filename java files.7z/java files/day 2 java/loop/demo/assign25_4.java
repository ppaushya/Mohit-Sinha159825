package org.cap.loop.demo;

public class assign25_4 {

	
	public static boolean isArmstrong(int num)
	{
		int a;
		int n=num;
		int sum=0;
		while(n!=0)
		{
			a=n%10;
			sum=sum+(a*a*a);
			n=n/10;
		}
		if(num==sum)
			return true;
		else
			return false;
	}
	public static void main(String[] args) {
		
		System.out.println("Armstrong number between 1 to 1000 are: ");
		for(int i=1;i<=1000;i++)
		{
			if(isArmstrong(i))
			{
				System.out.println(i);
			}
		}

	}

}