package org.cap.loop.demo;

import java.util.Scanner;

public class assign25_5 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String strin;
		System.out.println("Enter the string: ");
		strin=scanner.next();
		int len=strin.length();
		for(int i=0;i<len;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(strin.charAt(j));
			}
			System.out.println();
		}
		scanner.close();
	}

}