package org.sbi.dao;

import java.util.List;

import org.sbi.model.Account;
import org.sbi.model.Customer;

public interface ICustomerDao {
	
	public List<Customer> getAllCustomers();
	public void createCustomer(Customer customer);
    public void createaccounts(Customer customer,Account account);
}

