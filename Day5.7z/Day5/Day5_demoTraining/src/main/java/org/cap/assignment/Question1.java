package org.cap.assignment;

import Balance.Account;

public class Question1 extends Account{

	
	
	public static void main(String[] args)
	{
		Question1 obj=new Question1();
	   
	   obj.displayBalance();
	   
	}
} 
