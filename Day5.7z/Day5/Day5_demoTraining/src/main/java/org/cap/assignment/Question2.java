package org.cap.assignment;

	interface perimeter
	{
			static final float pi=3.142f;
			float compute(float x,float y);
	}
	
	
	class rectangle implements perimeter
	{
			public float compute(float x,float y)
			{
				return(2*(x+y));
			}
	}
	
	
	class circle implements perimeter
	{
			public float compute(float x,float y)
				{
					return(2*pi*x);
				}
	}
	
	
	public abstract class Question2
	{
			public static void main(String args[])
					{
					rectangle rect=new rectangle();
					circle cr=new circle();
					perimeter pr;
					pr=rect;
					System.out.println("Area of the rectangle= "+pr.compute(10,20));
					pr=cr;
					System.out.println("Area of the circle= "+pr.compute(10,0));
					}
	}


