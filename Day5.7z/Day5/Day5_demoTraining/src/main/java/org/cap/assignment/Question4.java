package org.cap.assignment;

	interface Student
	{
		void displayGrade();
		void attendence(int b);
	}
	class PG_Students implements Student
	{
	String name;
	int att;
	String grade;
	
	
	 public	void name(String n)
	{ 
			name=n; 
	}
	
	 public void attendence(int b)
		{ 
			 att=b;
		}
	 
	 
	public void displayGrade()
	{ 
		if(att<50)
		{
			grade="Bad";
		}
		
		if(att>50 && att <=70)
		{
			grade="Needs Improvement";
		}
		
		if(att>70 && att>100)
		{
			grade="Good";
		}
	}
	
	
	
	void disp()
		{
		System.out.println("Name :"+name);
		System.out.println("Grade :"+grade);
		System.out.println("Attendence :"+att);
		}
	}
	
	class UG_Students implements Student
	{
		String name;
		int att;
		String grade;
		
	
	
	 public	void name(String n)
	{ 
			name=n; 
	}
	 
	 public void attendence(int b)
		{ 
			att=b;
		}
	
	public void displayGrade()
	{ 
		if(att<50)
		{
			grade="Bad";
		}
		
		if(att>50 && att <=70)
		{
			grade="Needs Improvement";
		}
		
		if(att>70 && att>100)
		{
			grade="Good";
		}
	}
	
	
	
	void disp()
	{
		System.out.println("Name :"+name);
		System.out.println("Grade :"+grade);
		System.out.println("Attendence :"+att);
		}
	}

	public class Question4
	{
		
		public static void main(String args[])
		{ 
			PG_Students pg=new PG_Students();
			pg.name("Abhishek");
			pg.attendence(70);
			pg.displayGrade();
			pg.disp();
			UG_Students ug=new UG_Students();
			ug.name("Deepak");
			ug.attendence(30);
			ug.displayGrade();
			ug.disp();
		}
	}