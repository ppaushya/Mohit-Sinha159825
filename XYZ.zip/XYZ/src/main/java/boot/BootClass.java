package boot;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import model.Account;
import model.Customer;
import model.Transaction;
import services.CustomerServiceImpl;
import services.ICustomerService;
import utilPackage.Utility;
import view.UserInteraction;

public class BootClass {

	static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {
		ICustomerService customerService=new CustomerServiceImpl();
		UserInteraction userInteraction=new UserInteraction();
		
		int  choice;
                String option;
		do {
		System.out.println("1. Create Customer");
		System.out.println("2. List Customers");
		System.out.println("3. Create Account");
		System.out.println("4. Print Customer Details with Account info");
		System.out.println("5. Do Transaction");
                System.out.println("6. Transaction Summary");
		System.out.println("Enter Your choice:");
		choice=scanner.nextInt();
				
			switch(choice) {		
			case 1://enter new customer
				int count=customerService.getAllCustomers().size();
				
				Customer customer=userInteraction.getCustomerDetails();
				customerService.createCustomer(customer);
				
				if(count==customerService.getAllCustomers().size())
					userInteraction.printError("Customer Creation Error! Please Try Again!");
					
				
				break;
			case 2://print customer details
				List<Customer> customers= customerService.getAllCustomers();
				userInteraction.printCustomers(customers);
				break;
			case 3://create account
				System.out.println("Choose customer Id:");
				customers= customerService.getAllCustomers();
				userInteraction.printCustomers(customers);
				int customerId = scanner.nextInt();
				 customer=customerService.isCustomerFound(customerId);
				if(customer==null)
				{
					System.out.println("Customer ID not found.");
					break;
				}
				Account account=userInteraction.getAccountDetails();
				System.out.println(account);
				customerService.AddAccount(customer,account);
				break;
			case 4://print customer details with account details
				customers= customerService.getAllCustomers();
				userInteraction.printCustomersAccounts(customers);
				break;
                        case 5://transaction
                            System.out.println("Choose customer Id:");
                            customers= customerService.getAllCustomers();
                            userInteraction.printCustomers(customers);
                            customerId = scanner.nextInt();
			    customer=customerService.isCustomerFound(customerId);
			    if(customer==null)
			    {
                            System.out.println("Customer ID not found.");
			    break;
                            }
                            Transaction transaction=userInteraction.doTransaction(customer);
                            customerService.addTransaction(transaction);
                            System.out.println("Choose Account Number for Balance display:");
                            userInteraction.printAccounts(customer.getAccounts());
                            int accountNumber = scanner.nextInt();
                            account=customerService.isAccountFound(customer,accountNumber);
                            if(account==null)
                           {
                               System.out.println("Account does not exist for customer id- "+customer.getCustomerId());
                               break;
                           }
                            System.out.println("Current Balance="+customerService.getCurrentBalance(account,accountNumber));
                            
                            break;
                        case 6://transaction summary
                            List<Transaction> transactions= customerService.getAllTransaction();
                            userInteraction.printSummary(transactions);
                            break;
			default:
				System.out.println("Sorry! Invalid Choice");
				System.exit(0);
			
			}
			System.out.println("Do you wish to contine?[y|n]:");
			option=scanner.next();
			
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
		
		
		
	}

}
