package org.cap.demo;

public class assign1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
