package org.cap.demo;

public class Assign3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
