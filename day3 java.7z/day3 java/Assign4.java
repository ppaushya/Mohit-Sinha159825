package org.cap.demo;

import java.util.Scanner;

public class Assign4 {
	
	int row;
	int col;
	
	public static void main(String[] args)
	{
		int[][] arr1=new int[3][3];
		int[][] arr2=new int[3][3];
		Assign4 two = new Assign4();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Rows");
		two.row = scanner.nextInt();
		System.out.println("Enter Columns");
		two.col = scanner.nextInt();
		if(two.row == two.col)
		{
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					arr1[i][j]=scanner.nextInt();
				}
				System.out.println();
			}
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					if(j>i)
					{
						System.out.print(" ");
					}
					else
					{
						System.out.print(arr1[i][j]+" ");
					}
				}
				System.out.println();
			}
			System.out.println("\n");
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					if(i>j)
					{
						System.out.print("    ");
					}
					else
					{
						System.out.print(arr1[i][j]+" ");
					}
				}
				System.out.println();
			}
			System.out.println("\n");
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					
						System.out.print(arr1[j][i]+" ");
					
				}
				System.out.println();
			}
		}
		else
		{
			System.exit(0);
		}
	}
}
