package org.cap.Boot;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Account;
import org.cap.model.AccountType;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public class BootClass {

	public static void main(String[] args) {
		
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
           Customer customer=new Customer();
           Address address =new Address(101,"Road no-23","Sk Nagar","Patna","Bihar","800001");
           Account account=new Account();
           Transaction trans=new Transaction();
		
           customer.setCustomerId(1001);
           customer.setFirstName("Mohit");
           customer.setLastName("Sinha");
           customer.setDateOfBirth(LocalDate.now());
           customer.setEmailId("mohitwa@gmail.com");
           customer.setMobile("9875462314");
           customer.setCustomerPwd("123");
		
           account.setAccountNumber(1000001);
           account.setAccountType(AccountType.CURRENT);
           account.setOpeningDate(LocalDate.now());
           account.setOpeningBalance(10000.0);
           account.setDescription("Account generated ");
           
           transaction.commit();
	}

}
