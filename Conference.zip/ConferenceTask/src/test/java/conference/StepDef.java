package conference;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebElement element;
	private WebDriver webdriver;
	
	
	
	@Before
	public void setUp() {
		
		//init
		System.setProperty("webdriver.chrome.driver","D:\\Users\\mohsinha\\Desktop\\BDD\\chromedriver.exe" );
		webdriver=new ChromeDriver();
	}
	
	
	@Given("^Registration form page$")
	public void registration_form_page() throws Throwable {
	    webdriver.get("file:///D:/Users/mohsinha/Downloads/Conferencebooking/ConferenceRegistartion.html");
	}

	@When("^All the details are valid and filled$")
	public void all_the_details_are_valid_and_filled() throws Throwable {
	   
		webdriver.findElement(By.name("txtFN")).sendKeys("Rahul");
		//webdriver.findElement(By.name("txtLN")).sendKeys("Dravid");
		webdriver.findElement(By.name("Email")).sendKeys("rahul@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("7894561233");
		Select dropdown = new Select(webdriver.findElement(By.name("size")));
		dropdown.selectByVisibleText("3");
		webdriver.findElement(By.name("Address")).sendKeys("Ashiyana");
		webdriver.findElement(By.name("Address2")).sendKeys("Pune");
		
		Select dropdown1 = new Select(webdriver.findElement(By.name("city")));
		dropdown1.selectByVisibleText("Hyderabad");

		Select dropdown2 = new Select(webdriver.findElement(By.name("state")));
		dropdown2.selectByVisibleText("Telangana");
		WebElement radio1 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));
		        //Radio Button1 is selected
		        radio1.click();
		        
  WebElement radio2 = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input"));
		       
  radio2.click();}
		        
  @Then("^Click Next Button,navigate to next page$")
  public void click_Next_Button_navigate_to_next_page() throws Throwable {      
WebElement click = webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));							
		        			 		
		        			      
 click.click();	
		        			        

  Alert alert = webdriver.switchTo().alert();
  
  String test=alert.getText();
  if(test.compareTo("Personal details are validated")==0)
     alert.accept();
		        			      
  webdriver.navigate().to("file:///D:/Users/mohsinha/Downloads/Conferencebooking/PaymentDetails.html"); 
	
  }	        		 

		@Then("^fill details of payment page$")
	    public void fill_details_of_payment_page() throws Throwable {
			
			webdriver.findElement(By.name("txtFN")).sendKeys("Rahul");
			webdriver.findElement(By.name("debit")).sendKeys("7234567897894561");
			webdriver.findElement(By.name("cvv")).sendKeys("123");
			webdriver.findElement(By.name("month")).sendKeys("November");
			webdriver.findElement(By.name("year")).sendKeys("2018");
			
			WebElement makepayment = webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));	
			makepayment.click();
			
			
			
			
			
			
		        			      
	}

}
