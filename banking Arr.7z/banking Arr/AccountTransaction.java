package org.cap.demo;

public class AccountTransaction {

}
