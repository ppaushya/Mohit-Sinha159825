package org.gaming.util;

import org.gaming.model.Registration;

public class Utility {

	
	public static boolean isvalidcustomer(Registration reg)
	{
		 if(reg.getCustomerName().matches("[a-zA-Z]+"))
		 {
			 if(reg.getMobileNumber().matches("(7|8|9){1}[0-9]{9}"))
			 {
				 return true;
			 }
		 }
		 return false;
	}
	
	public static int generateNumber() {
		int c=(int)(Math.random()*1000)/10;
		for(int i=0;i<(int)(Math.random()*1000)/100;i++)
		{
			c=c+i;
		}
		
		return c;
	}
}

