package org.gaming.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import org.gaming.model.Registration;
import org.gaming.services.CustomerServicesImpl;

import com.mysql.jdbc.PreparedStatement;

public class CustomerDaoImpl implements ICustomerDao {

	@Override
	public void customerRegistration(Registration registration) {
		// TODO Auto-generated method stub
		CustomerServicesImpl obj=new CustomerServicesImpl();
		String SQL = "insert into registration(customername,mobilenumber,registrationfee,age,actualregfeepaid) values(?,?,?,?,?)";
		String nextSQL="select * from registration";
		try(Connection connection = getDbConnection())
		{
		     java.sql.PreparedStatement prepared=connection.prepareStatement(SQL);
		     prepared.setString(1, registration.getCustomerName());
		     prepared.setString(2, registration.getMobileNumber());
		     prepared.setDouble(3,registration.getRegistrationFee());
		     prepared.setInt(4, registration.getAge());
		     prepared.setDouble(5, registration.getActualRegFeePaid());
		    
		     int count=prepared.executeUpdate();		    
		     

		     if(count>=1)
		     {
		    	 System.out.println("Insertion done!");
		    	 
		    	 java.sql.PreparedStatement preparedStatement=connection.prepareStatement(nextSQL);
			     
			     ResultSet res=preparedStatement.executeQuery();
			     
			     while(res.next())
			     {
			    	 if(res.getString(2).compareTo(registration.getCustomerName())==0)
			    	 {
			    		 System.out.println("Acknowledgement Slip");
			    		 System.out.println("Registration Id : " +res.getInt(1));
					     System.out.println("Congratulations " +res.getString(2)+" your Registration has been done");
					     System.out.println("Your actual amount paid: " +res.getString(6));
			    	 }
			     }  
			     
		     }
		     else
		     {
		    	 System.out.println("insertion error");
		     }
		     
		     
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			obj.logger.error("connection error",e);
			//e.printStackTrace();
		}
		
		
	}
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			//e.printStackTrace();
		}
		
		return null;
		
	}

}
