package org.gaming.services;

import org.gaming.Dao.CustomerDaoImpl;
import org.gaming.Dao.ICustomerDao;
import org.gaming.exceptions.InvalidCustomerException;
import org.gaming.model.Registration;
import org.gaming.util.Utility;

import org.apache.log4j.Logger;


public class CustomerServicesImpl implements ICustomerServices{

	ICustomerDao customerDao= new CustomerDaoImpl();
   public final static Logger logger=Logger.getLogger(CustomerServicesImpl.class);
   
   public void runMe(String parameter)
	{
		if(logger.isDebugEnabled())
		{
			logger.debug("This is debug: "+parameter);
		}
		
		if(logger.isInfoEnabled())
		{
			logger.info("This is info: "+parameter);
		}
		
		logger.warn("This is warning: "+parameter);
		logger.error("This is error: "+parameter);
		logger.fatal("This is fatal: "+parameter);
	}
   
   
	@Override
	public boolean customerRegistration(Registration registration) throws InvalidCustomerException {
		// TODO Auto-generated method stub
		//validate customer
		
		if(Utility.isvalidcustomer(registration))
		{
 		customerDao.customerRegistration(registration);
 		return true;
		}
		else
		{
	       logger.error("Not Valid Customer");	
			throw new InvalidCustomerException("Details are wrong!!!");
			
		}
		
	}

	
	
	
	
}
