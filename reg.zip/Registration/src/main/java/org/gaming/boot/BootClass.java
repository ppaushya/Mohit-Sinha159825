package org.gaming.boot;

import java.util.Scanner;

import org.gaming.Dao.ICustomerDao;
import org.gaming.exceptions.InvalidCustomerException;
import org.gaming.model.Registration;
import org.gaming.services.CustomerServicesImpl;
import org.gaming.services.ICustomerServices;
import org.gaming.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) throws InvalidCustomerException
	{
		Scanner scanner= new Scanner(System.in);
		
		UserInteraction userInteraction = new UserInteraction();
		
		ICustomerServices customerServices = new CustomerServicesImpl();

		String option;
		
		
		do
		{
		Registration newRegistration=userInteraction.getregistrationdetails();
		
		System.out.println(newRegistration);
		
		customerServices.customerRegistration(newRegistration);
	
		
		System.out.println("Do you wish to contine?[y|n]:");
		option=scanner.next();
		
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
	}
	
}
