package org.gaming.view;

import java.util.Scanner;

import org.gaming.util.Utility;
import org.gaming.model.Registration;

public class UserInteraction {

	Scanner scanner = new Scanner(System.in);
	
	public Registration getregistrationdetails()
	{
		Registration newRegistration=new Registration();
		
		System.out.println("New Registration");
		
		System.out.println("Enter the Name: ");
		
		String name=scanner.next();
		
		newRegistration.setCustomerName(name);
		
		System.out.println("Enter the mobile number: ");
		
		String mobileNo = scanner.next();
		
		newRegistration.setMobileNumber(mobileNo);
		
		System.out.println("Enter the registration fee: ");
		
		double regFees=scanner.nextDouble();
		
		newRegistration.setRegistrationFee(regFees);
	    
		System.out.println("Enter the age of customer: ");
		
		int age=scanner.nextInt();
		
		newRegistration.setAge(age);
		
		
		double actualRegFeePaid=calculatefees(regFees,age);
		
		newRegistration.setActualRegFeePaid(actualRegFeePaid);
		
		
		return newRegistration;
	}
	
	public void printAcknolwedge(Registration registration)
	{
	     System.out.println("Registration Id :"+registration.getRegistrationId());
	     System.out.println("Congratulations " + registration.getCustomerName() + "you have registered succesfully");
	     System.out.println("Actual amount paid after concession: " + registration.getActualRegFeePaid() );
	}
	
	public double calculatefees(double fees,int age)
	{
		if(age>=0 && age<18)
		{
			return fees;
		}
		else if(age>=18 && age<25)
		{
			return 1.1 * fees;
		}
		else if(age>=25 && age<50)
		{
			return 1.2 * fees;
		}
		else 
		{
			return 1.3 * fees;
		}
		
	}
}
